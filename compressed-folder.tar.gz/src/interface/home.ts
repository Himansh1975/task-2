export type PageNumbers = 0 | 1 | 2;
