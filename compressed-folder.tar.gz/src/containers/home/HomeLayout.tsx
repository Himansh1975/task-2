import React, { useState } from "react";
import {
  Container,
  Tabs,
  TabList,
  Tab,
  TabPanels,
  TabPanel,
  Heading,
  Box,
  Grid,
} from "@chakra-ui/react";
import InterviewSettingsForm from "./InterviewSettingsForm";
import JobDetailsForm from "./JobDetailsForm";
import RequisitionForm from "./RequisitionDetailsForm";
import PreviewCard from "./PreviewCard";


const CustomTab = ({ children, ...props }: { children: React.ReactNode }) => {
  return (
    <Tab p="1rem" fontFamily="Poppins" {...props}>
      {children}
    </Tab>
  );
};

const HomeLayout = () => {
  const [activeTab, setActiveTab] = useState(0);

  const handleNextTab = () => {
    setActiveTab((prevTab) => prevTab + 1);
  };

  const handlePreviousTab = () => {
    setActiveTab((prevTab) => prevTab - 1);
  };

  return (
    <Box w="100%">
      <Container maxW="1200px">
        <Heading fontFamily="Poppins" fontSize="1.5rem" my="2rem">
          Create Candidate Requisition
        </Heading>
        <Tabs
          isLazy
          index={activeTab}
          onChange={(index) => setActiveTab(index)}
        >
          <TabList>
            <CustomTab>Requisition Details</CustomTab>
            <CustomTab>Job Details</CustomTab>
            <CustomTab>Interview Settings</CustomTab>
          </TabList>
          <Grid display="grid" gridTemplateColumns="3fr 2fr" gap="24px">
            <TabPanels>
              <TabPanel>
                <RequisitionForm handleNextTab={handleNextTab} />
              </TabPanel>
              <TabPanel>
                <JobDetailsForm
                  handleNextTab={handleNextTab}
                  handlePreviousTab={handlePreviousTab}
                />
              </TabPanel>
              <TabPanel>
                <InterviewSettingsForm
                  handlePreviousTab={handlePreviousTab}
                />
              </TabPanel>
            </TabPanels>
            <PreviewCard />
          </Grid>
        </Tabs>
      </Container>
    </Box>
  );
};

export default HomeLayout;
